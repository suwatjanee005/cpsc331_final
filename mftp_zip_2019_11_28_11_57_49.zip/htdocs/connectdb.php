<?php 
	//$serverName = "localhost";
	$serverName = "sql110.epizy.com";
	$userName = "epiz_24677474";
	$userPassword = "s1f9bTGfNLMJiTF";
	$dbName = "epiz_24677474_fearno71";
	$conn = mysqli_connect($serverName,$userName,$userPassword,$dbName);
?>