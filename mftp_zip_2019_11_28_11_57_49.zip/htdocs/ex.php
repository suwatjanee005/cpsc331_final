<?php include("header.php"); ?>

<!DOCTYPE html>

<html>
<title>เครื่องปริ้นเตอร์อิงค์แทงค์รุ่นเล็ก</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body,h1,h2,h3,h4,h5,h6 {font-family: "Raleway", sans-serif}

body, html {
  height: 100%;
  line-height: 1.8;
}

/* Full height image header */
.bgimg-1 {
  background-position: center;
  background-size: cover;
  background-image: url("/w3images/mac.jpg");
  min-height: 100%;
}

.w3-bar .w3-button {
  padding: 16px;
}
</style>
<body>
    <Center><h1>เครื่องปริ้นเตอร์อิงค์แทงค์รุ่นเล็ก</h1></Center>
<div class="w3-container w3-light-grey" style="padding:60px 16px">
  <div class="w3-row-padding">
    <div class="w3-col m6">
      <h3>Canon PIXMA G2010</h3>
      <p>เครื่องปริ้นเตอร์อิงค์แทงค์จากค่าย Canon ที่ครอบคลุมการใช้งานแบบมัลติฟังก์ชั่นทั้ง Print Scan Copy ประหยัดหมึกด้วยระบบอิงค์แทงค์ ได้งานพิมพ์ด้วยต้นทุ่มที่ถูกลง ตัวเครื่องออกแบบให้เห็นระดับหมึกได้ง่าย สามารถทำความเร็วการพิมพ์ขาว-ดำ 8.8 ภาพ/นาที พิมพ์สี 5 ภาพ/นาที ความละเอียดในการพิมพ์อยู่ที่ 4,800 x 1,200 dpi สามารถพิมพ์ไร้ขอบ A4 ได้ ทำให้การพิมพ์ภาพน่าประทับใจมากขึ้น

เครื่องปริ้นเตอร์อิงค์แทงค์รุ่นนี้ เหมาะกับการใช้งานส่วนตัวที่บ้าน ถาดหลังใส่กระดาษได้ 100 แผ่น รองรับการเชื่อมต่อ USB 2.0 High-Speed ใช้งานได้กับระบบ Windows 10/8.1/7 ServicePack 1 *แต่ไม่รองรับ Mac OS* สนนราคาที่ 4,190 บาท</p>

     </div>
    <div class="w3-col m6">
      <img class="w3-image w3-round-large" <img src = "image\p2.jpg" alt="Buildings" width="300" height="394">
</div>
  </div>
</div>

<div class="w3-container" style="padding:60px 16px">
  <div class="w3-row-padding">
    <div class="w3-col m6">
      <h3>Canon PIXMA G3000</h3>
      <p>อีกหนึ่งเครื่องปริ้นเตอร์อิงค์แทงค์ที่เป็นตัวเลือกอันดับต้นๆ ของกลุ่มผู้ใช้ทั่วไปหรือซื้อใช้ในโฮมออฟฟิศก็ตาม เป็นรุ่น Top สุดในบรรดาซีรีส์ G ทั้ง 3 ตัว (G1000, G2000, G3000) ของค่าย Canon ด้วยฟังก์ชั่นแบบ 3 in 1 คือ Print Scan Copy ความละเอียดในการพิมพ์อยู่ที่ 4,800 x 1,200 dpi สามารถพิมพ์งานขาวดำได้ 8.8 ภาพ/นาที และภาพสีที่ 5 ภาพ/นาที ปริมาณการพิมพ์ต่อการเติมหมึก 1 ชุดอยู่ที่ 6,000 แผ่นสำหรับขาวดำและ 7,000 แผ่น สำหรับพิมพ์สี แถมด้วยแทงค์หมึกที่ง่ายต่อการสังเกตระดับหมึก

ความโดดเด่นของเครื่องปริ้นเตอร์อิงค์แทงค์รุ่นนี้ คือความสามารถในการพิมพ์รูปภาพไร้ขอบขนาด 4 x 6 นิ้วภายใน 60 วินาที แถมยังมีความสวยงามของสีที่สมจริงอีกด้วย ความแตกต่างจาก Canon Pixma G2010 ก็คือ สามารถสั่งงานไร้สายผ่านระบบ Wi-Fi จากบนสาร์ทโฟนได้ ความเหนือกว่าของเครื่องปริ้นเตอร์อิงค์แทงค์รุ่นนี้ คือสั่งงานผ่านระบบ Cloud ได้อีกด้วย ราคาเครื่องอยู่ที่ 5,490 บาท</p>

     
    </div>
    <br>
<br>
    <div class="w3-col m6">
      <img class="w3-image w3-round-large" <img src = "image\p3.jpg" alt="Buildings" width="300" height="394">
    </div>
  </div>
</div>

<div class="w3-container w3-light-grey" style="padding:60px 16px">
  <div class="w3-row-padding">
    <div class="w3-col m6">
      <h3>HP Ink Tank 315</h3>
      <p>สำหรับทางค่าย HP เครื่องปริ้นอิงค์แทงค์มัลติฟังก์ชั่น ทั้ง Print Scan Copy ตัวแรก คือรุ่น HP Ink Tank 315 ความละเอียดในการพิมพ์สี อยู่ที่ 4,800 x 1,200 dpi และ ขาวดำอยู่ที่ 1,200 x 1,200 dpi สำหรับการทำความเร็วในงานพิมพ์ก็ถือว่าอยู่ในเกณฑ์มาตรฐานคือ ขาวดำที่ 19 แผ่น/นาที และสี 15 แผ่น/นาที ดีไซน์กะทัดรัด เชื่อมต่อเพื่อใช้งานได้ด้วย USB 2.0 High-Speed ราคาอยู่ที่ 4,590 บาท</p>

     </div>
    <div class="w3-col m6">
      <img class="w3-image w3-round-large" <img src = "image\p4.jpg" alt="Buildings" width="300" height="394">
</div>
  </div>
</div>

<div class="w3-container" style="padding:60px 16px">
  <div class="w3-row-padding">
    <div class="w3-col m6">
      <h3>HP Ink Tank 415</h3>
      <p>มาถึงเครื่องปริ้นเตอร์อิงค์แทงค์แบบมัลติฟังก์ชั่นของทางฝั่ง HP เป็นเครื่องปริ้นเตอร์แบบ 3-in-One ทั้ง Print Scan Copy โดยความละเอียดในการพิมพ์สี อยู่ที่ 4,800 x 1,200 dpi และ ขาวดำอยู่ที่ 1,200 x 1,200 dpi สำหรับการทำความเร็วในงานพิมพ์ก็ถือว่าอยู่ในเกณฑ์มาตรฐานคือ ขาวดำที่ 19 แผ่น/นาที และสี 15 แผ่น/นาที

ความน่าสนใจของเครื่องปริ้นเตอร์อิงค์แทงค์รุ่นนี้คือ สามารถพิมพ์ภาพ A4 แบบไร้ขอบได้ การสั่งงานที่สะดวกมากขึ้น สามารถทำได้ผ่านสมาร์ทโฟนบนแอปพลิเคชั่น Smart HP และพิมพ์งานผ่านระบบ Wi-Fi Direct ในราคา 5,590 บาท</p>
</div>
    <div class="w3-col m6">
      <img class="w3-image w3-round-large" <img src = "image\p5.jpg" alt="Buildings" width="300" height="394">
</div>
  </div>
</div>

<div class="w3-container w3-light-grey" style="padding:60px 16px">
  <div class="w3-row-padding">
    <div class="w3-col m6">
      <h3>Brother DCP-T310</h3>
      <p>เครื่องปริ้นเตอร์อิงค์แทงค์ Brother DCP-T310 อีกหนึ่งเครื่องปริ้นเตอร์สำหรับคนที่มองหาความคุ้มค่า ฟังก์ชั่นการทำงานแบบ 3-in-One ทั้ง Print Scan Copy ให้ความละเอียดการพิมพ์ที่ 1,200 x 6,000 dpi มีระบบ Fast Mode ที่ช่วยให้การพิมพ์งานเร็วขึ้น พิมพ์สีอยู่ที่ 10 แผ่น/นาที พิมพ์ขาวดำสูงถึง 27 แผ่น/นาที

การออกแบบตัวเครื่อง สามารถมองเห็ยปริมาณน้ำหมึกได้ง่าย พร้อมจอ LCD 1 บรรทัด ที่จะแสดงสถานการณ์ทำงานให้เห็นได้สะดวก พร้อมถาดป้อนกระดาษที่รองรับได้สูงถึง 150 แผ่น ช่วยให้การทำงานลื่นไหล เชื่อมต่อด้วย USB 2.0 ทั้งหมดนี้ในราคา 4,590 บาท</p>

     </div>
    <div class="w3-col m6">
      <img class="w3-image w3-round-large" <img src = "image\p6.jpg" alt="Buildings" width="300" height="394">
</div>
  </div>
</div>

<div class="w3-container" style="padding:60px 16px">
  <div class="w3-row-padding">
    <div class="w3-col m6">
      <h3>Brother DCP-T510W</h3>
      <p>เครื่องปริ้นเตอร์อิงค์แทงค์แท้จาก Brother รุ่น DCP-T510 มัลติฟังก์ชั่นปริ้นเตอร์ที่ใช้งานแบบ 3 in 1 ทั้ง Print Scan Copy ความเร็วในการเริ่มพิมพ์สีแผ่นแรก เพียง 14 วินาที และพิมพ์ขาวดำใน 8 วินาที ทำงานก็สามารถพิมพ์ขาวดำได้ที่ 12 แผ่น/นาที และพิมพ์สีที่ 6 แผ่น/นาที ความละเอียดสูงสุดที่ทำได้อยู่ที่ 1,200 x 6,000 dpi

ตัวถาดใส่กระดาษของเครื่องปริ้นเตอร์อิงค์แทงค์รุ่นนี้ ผลิตมาให้รองรับได้ถึง 150 แผ่น และสามารถใส่กระดาษแบบทีละแผ่นจากด้านหลังได้ สำหรับหมึกพิมพ์ 1 ชุด สีดำพิมพ์ได้ 6,500 แผ่น พิมพ์สีอยู่ที่ 5,000 แผ่น สั่งงานสะดวกและง่ายผ่านสมาร์ทโฟนบนแอพพลิเคชั่น Brothe iPrint&Scan และรองรับ Wi-Fi พร้อมจอแสดงผล LCD 1 บรรทัด ช่วยให้ง่ายต่อการทำงานและเช็คสถานะการทำงานของเครื่อง สำหรับราคาอยู่ที่ 5,190 บาท</p>
</div>
<br>
<br>
<br>
    <div class="w3-col m6">
      <img class="w3-image w3-round-large" <img src = "image\p7.jpg" alt="Buildings" width="300" height="394">
</div>
  </div>
</div>

<div class="w3-container w3-light-grey" style="padding:60px 16px">
  <div class="w3-row-padding">
    <div class="w3-col m6">
      <h3>EPSON L4150</h3>
      <p>เครื่องปริ้นเตอร์อิงค์แทงค์รุ่นแรกจากทาง EPSON คือรุ่น EPSON L4150 ฟังก์ชั่นครบครันทั้ง Print Scan Copy ความละเอียดในการพิมพ์ถึง 5,760 × 1,440 dpi ความเร็วในการพิมพ์สี 10.5 รูป/นาที และพิมพ์สี 5 รูป/นาที รองรับการพิมพ์ภาพแบบไร้ขอบขนาด A4

เครื่องปริ้นเตอร์อิงค์แทงค์รุ่นนี้ เป็นรุ่นใหม่ที่ทาง EPSON ออกแบบถังหมึกให้อยู่ภายในตัวเครื่อง ทำให้ประหยัดพื้นที่ในการวาง และหมึกเติมง่าย ไม่เลอะมือ รองรับการสั่งงานแบบไร้สายทั้ง Wi-Fi, Wi-Fi Direct สั่งงานผ่านสมาร์ทโฟนและอุปกรณ์เคลื่อนที่อื่นๆ ได้ผ่านแอพพลิเคชั่น สนนราคาอยู่ที่ 5,990 บาท</p>

     </div>
    <div class="w3-col m6">
      <img class="w3-image w3-round-large" <img src = "image\p8.jpg" alt="Buildings" width="300" height="394">
</div>
  </div>
</div>

<div class="w3-container" style="padding:60px 16px">
  <div class="w3-row-padding">
    <div class="w3-col m6">
      <h3>EPSON L360</h3>
      <p>EPSON L360 เครื่องปริ้นเตอร์อิงค์แทงค์ที่มีขนาดกะทัดรัดไม่เปลืองพื้นที่ เป็นเครื่องปริ้นเตอร์อิงค์แทงค์แบบมัลติฟังก์ชั่น รองรับได้ทั้งงาน Print Copy Scan คมชัดทุกรายละเอียด สามารถทำความละเอียดได้ที่ 5,760 x 1,440 dpi สามารถพิมพ์งานขาวดำได้ 33 แผ่น/นาที ในส่วนงานพิมพ์สีอยู่ที่ 15 แผ่น/นาที

เครื่องปริ้นเตอร์อิงค์แทงค์รุ่นนี้ รองรับเฉพาะการเชื่อมต่อแบบ USB 2.0 เท่านั้น สนนราคาอยู่ที่ 4,090 บาท เหมาะกับการเป็นเครื่องปริ้นเตอร์ส่วนตัวในราคาย่อยเยาว์</p>
</div>

    <div class="w3-col m6">

      <img class="w3-image w3-round-large" <img src = "image\p9.jpg" alt="Buildings" width="300" height="394">
</div>
  </div>
</div>

<div class="w3-container w3-light-grey" style="padding:60px 16px">
  <div class="w3-row-padding">
    <div class="w3-col m6">
      <h3>EPSON L405</h3>
      <p>เครื่องปริ้นเตอร์อิงค์แทงค์อีกรุ่นจากค่าย EPSON ที่ทำงานแบบมัลติฟังก์ชั่นอิงค์เจ็ท ด้วยคุณสมบัติที่สามารถใช้งานได้ครบทั้ง Print Scan Copy ขนาดตัวเครื่องเท่ากับเครื่องปริ้นเตอร์ EPSON L360 จึงเหมาะกับการวางไว้ทุกมุม สำหรับประสิทธิภาพการทำงาน ความละเอียดในงานพิมพ์ทำได้ถึง 5,760 x 1,440 dpi และสามารถทำความเร็วในการพิมพ์ขาวดำได้ที่ 33 ภาพ/นาที และภาพสีที่ 15 ภาพ/นาที

อีกความโดดเด่นที่ใส่เพิ่มเข้ามาจากเครื่องปริ้นเตอร์อิงค์แทงค์ EPSON L360 นั่นคือเจ้าตัว EPSON L405 รุ่นนี้สามารถเชื่อมต่อผ่านระบบ Wi-Fi ได้ ทำให้สั่งพิมพ์งานจากสมาร์ทโฟนบนแอปพลิเคชั่น EPSON iPrint (รองรับทั้ง iOS และ Android) ได้อย่างสะดวกสบาย ถือว่าคุ้มค่าที่เดียวสำหรับเครื่องปริ้นเตอร์ในราคา 5,050 บาท</p>

     </div>
    <div class="w3-col m6">
      <img class="w3-image w3-round-large" <img src = "image\p10.jpg" alt="Buildings" width="300" height="394">
</div>
  </div>
</div>

</script>

</body>
</html>

<?php include("footer.php"); ?>