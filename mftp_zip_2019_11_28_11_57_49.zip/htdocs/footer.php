
<footer class="w3-container w3-padding-60 w3-center w3-opacity w3-light-grey w3-xlarge">
 
 <a href="https://www.facebook.com/Fafearn89" class="fa fa-facebook-official w3-hover-opacity" ></a>

<a href="https://www.instagram.com/_ffarnn_/" class="fa fa-instagram w3-hover-opacity"></a>

<a href="https://twitter.com/Fafearn89" class="fa fa-twitter w3-hover-opacity"></a>
<br>E-mail : fearn-a27@hotmail.com
</footer>
  