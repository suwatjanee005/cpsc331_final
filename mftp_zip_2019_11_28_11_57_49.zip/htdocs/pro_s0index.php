<?php include("header01.php"); ?>
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
</head><body><ol><b>Manage data in mysql</b>
<li>s1connect.php</li>
<li><a href="pro_s2crtdb.php">s2crtdb.php</a></li>
<li><a href="pro_s3select.php">s3select.php</a></li>
<li><a href="pro_s4insert.php">s4insert.php</a></li>
<li><a href="pro_s5delete.php">s5delete.php</a></li>
<li><a href="pro_s6update.php">s6update.php</a></li>
<li><a href="pro_s7drop.php">s7drop.php</a></li>
</ol>
<?php

  if(file_exists("pro_s3select.php")) include("pro_s3select.php");
?>
<?php include("footer.php"); ?>