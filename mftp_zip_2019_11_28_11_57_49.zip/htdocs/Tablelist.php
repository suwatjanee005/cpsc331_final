<?php include("header.php"); ?>
<?php


//echo $_SESSION["STATUS"];

if (!isset($_SESSION["STATUS"]) || ($_SESSION["STATUS"]) < 2 )
{
    
	header("location: logout.php");
	exit();
}
?>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!--<TABLE  align="center" width="624" height="800" border="1">

<!--<?php include("Select.php"); ?>

<?php include("Select2.php"); ?>
<br><br><br><br> -->
<Center><h1>ตารางแสดงข้อมูล</h1></Center></font>
 

<?php include("Select3.php"); ?>

</div></div>

<?php include("footer.php"); ?>