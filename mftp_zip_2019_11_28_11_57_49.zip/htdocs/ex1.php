<?php include("header.php"); ?>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<Center><h1>ที่เที่ยวเชียงใหม่</h1></Center>
             
                <br>

               <center><table width=80% style="border:3px dashed #A020F0;" cellspacing="5" bgcolor="#A020F0" 
                cellpadding="5"><tr><td style="border:3px dashed white;" gcolor="white" 
                    background=http://diary.yenta4.com/diary_folder/53229/53229_uploaded/BG/bk64r-10.gif
                    ><h2>ประตูท่าแพ</h2>

                 <p>
                 ปักหมุดพิกัดถ่ายรูปสวยของเชียงใหม่ที่แรกกันเลยกับ ประตูท่าแพ ค่ะ ซึ่งตรงนี้เองเป็น 1 ใน 5 ประตูเมืองชั้นในของเวียงเชียงใหม่ในสมัยอดีต เป็นกำแพงเมืองที่มีความสำคัญกับประวัติศาสตร์เมืองเชียงใหม่เลยทีเดียว แน่นอนว่า มุมน่าถ่ายรูปก็คือกำแพงที่ก่อสร้างด้วยอิฐ จะไปยืนถ่ายยังไง โพสท่าไหนก็เก๋ๆ </p>
                            <br><center><img src = "image\c1.jpg" width="400" height="400" border="1"></center></td></tr></table>
                           
                        </center>
<br><br>
                        <center><table width=80% style="border:3px dashed #A020F0;" cellspacing="5" bgcolor="#A020F0" 
                            cellpadding="5"><tr><td style="border:3px dashed white;" gcolor="white" 
                                background=http://diary.yenta4.com/diary_folder/53229/53229_uploaded/BG/bk64r-10.gif
                                ><h2>One Nimman</h2>
                             <p>One Nimman ที่เที่ยวที่เป็นเหมือนแลนด์มาร์คบนถนนนิมมานเหมินทร์เลยทีเดียว เราสามรรถเดินชิลๆ ไป ถ่ายรูปไป ได้ฟีลบรรยากาศฟีลเมืองนอกมากๆ ค่ะ โดดเด่น ด้วยสถาปัตยกรรมล้านนาร่วมสมัยผสมผสานกับตะวันตกเป็นอาคารตึกสูงเรียงรายกันด้วยอิฐดินเผาสีส้ม ด้านในก็จะเต็มไปด้วยร้านค้า ร้านอาหาร คาเฟ่ต่างๆ ให้ได้ไปนั่งชิลพิกัด : เลขที่ 1 ถนนนิมมานทร์เหมินทร์ เทศบาลนครเชียงใหม่ อำเภอเมือง จังหวัดเชียงใหม่ 
                            โทร : 0-5208-0900
เว็บไซต์ : http://www.onenimman.com, https://www.facebook.com/onenimman</p>
                                        <br><center><img src = "image\c2.jpg" width="400" height="400" border="1"></center></td></tr></table>
                                       
                                    </center>

                                    <br><br>
                        <center><table width=80% style="border:3px dashed #A020F0;" cellspacing="5" bgcolor="#A020F0" 
                            cellpadding="5"><tr><td style="border:3px dashed white;" gcolor="white" 
                                background=http://diary.yenta4.com/diary_folder/53229/53229_uploaded/BG/bk64r-10.gif
                                ><h2>พิพิธภัณฑ์เซรามิคธนบดี : Dhanabadee Ceramic Museum</h2>
                             <p>   ผาช่อ ป็นปรากฏการณ์ตามธรรมชาติที่เกิดจากการกัดเซาะของลมฝน จนกลายเป็นแผ่นดินที่สูงถึง 30 เมตร ค้ลายๆ เป็นหน้าผาตลอดแนวยาว ซึ่งจะมีลวดลายสวยงามอีกด้วยค่ะ เป็นที่เที่ยวธรรมชาติอีกแห่งที่น่าอัศจรรย์ใจมากๆ นักท่องเที่ยวจึงนิยมมาเดินชมความสวยงาม และถ่ายรูปกลับไปเป็นที่ระลึกอีกด้วย พิกัด : อุทยานแห่งชาติแม่วาง อำเภอดอยหล่อ จังหวัดเชียงใหม่
โทร : 08-1881-4729, 06-3523-9518
เว็บไซต์ : -

</p>
                                        <br><center><img src = "image\c3.jpg" width="400" height="400" border="1"></center></td></tr></table>
                                       
                                    </center>
                                    <br><br>


<?php include("footer.php"); ?>