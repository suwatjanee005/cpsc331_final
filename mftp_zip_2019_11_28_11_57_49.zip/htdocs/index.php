<?php include("header.php"); ?>

<center><h1>Aboutme</h1><center>
                <center><br><img src="image\1.jpg" alt="flower" width="300" height="300"><center>

                
                <br><br><br> <table  width=70% style="border:3px dashed IndianRed;" cellspacing="5" 
                bgcolor="IndianRed" cellpadding="7"><tr><td style="border:3px dashed "IndianRedSSS;
                bgcolor="Wheat"
                     ><center>ชื่อ-สกุล : นางสาว สุวัจนีย์   ปัญญาภู</center>
                    <br><center>Name : Suwatjanee Punyapoo</center>
                    <br><center>ชื่อเล่น : ใบเฟิร์น</center> 
                    <br><center>Nickname : Fearn</center>
                    <br><center>อายุ : 20 ปี</center>
                    <br><center>ปัจจุบันศึกษาอยู่ที่มหาวิทยาลัยเนชั่น</center> 
                    <br><center>คณะบริหารธุรกิจและรัฐประศาสนศาสตร์</center> 
                    <br><center>สาขาวิทยาการคอมพิวเตอร์ ชั้นปีที่ 2</center>
                    <br><center><a href="http://www.nation.ac.th/index2.php?lang=th">Nation University</a></center>

                    <br><center>วัน/เดือน/ปี เกิด : 8 กันยายน 2541</center>
                    <br><center>น้ำหนัก ส่วนสูง ปัจจุบัน : 39 กิโลกรัม ส่วนสูง 159 เซนติเมตร</center>
                    <br><center>วิชาที่ชอบ : ภาษาอังกฤษ วิทยาศาสตร์ คอมพิวเตอร์</center>
                    <br><center>สีที่ชอบ : สีขาว สีดำ สีทอง สีเทา</center>
                    <br><center>ที่อยู่ : 444 หมู่2 ถนนวชิราวุธดำเนิน ตำบลพระบาท อำเภอเมือง จังหวัดลำปาง 52000</center>
                    <br><center>ติดต่อ</center>
                    <br><center>เบอร์โทร : 0987646992</center>
                    <br><center>Facebook :<a href="https://www.facebook.com/Fafearn89">Suwatjanee Punyapoo</a></center>
                    <br><center>Line : Fafearn89.</td></tr></table></center>
                    <br>
                    <br>

	

 <?php include("footer.php"); ?>