<?php include("header.php");?>
<?php include ("font_f.php");?>
<center><h1>Pyramid9</h1></center>

<?php
for($fearn=1;$fearn<=5;$fearn++) {
	for($col=3;$col<=1+$fearn;$col++) {
	echo(" ");
	}
	for($col=0;$col<=5-$fearn;$col++){
		echo($fearn);
	}
	for($col=0;$col<=4-$fearn;$col++){
		echo($fearn);
	}
	echo "<br/>";
}
?>

<?php include("footer.php"); ?>