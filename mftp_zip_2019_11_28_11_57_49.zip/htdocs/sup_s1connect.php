<?php
ini_set('display_errors', 0);  
$host = "sql110.epizy.com"; 
$uname = "epiz_24677474";
$upass 	= "s1f9bTGfNLMJiTF";
$db = "epiz_24677474_fearno71";
$tb			= "Suppliers";
$dbstatus 	= 0;
myConnect();
       
function myConnect() {
	global $db,$host,$uname,$upass,$connect,$dbstatus;	
    //echo  $db,$host,$uname,$upass,$connect,$dbstatus;
	if((int)phpversion() >= 7) {
		$connect = new mysqli($host, $uname, $upass, $db);
		if ($connect->connect_error) $connect = new mysqli($host, $uname, $upass); else $dbstatus = 1;
        
		if ($connect->connect_error) die("Connection failed: " . $connect->connect_error);
	} else {
		if(!$connect = mysql_connect($host,$uname,$upass)) die("Connect failed : ");
          
	}
}

?>
