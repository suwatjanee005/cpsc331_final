<?php 
include("header.php"); ?>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<form action="CheckLog.php" name="frmAdd" method="post">
  <br>
  <br>
<center><table width="284" border="1" >
  <tr>
    <th colspan="2" align="center">Login Form</th>
      </tr>
  <tr>
    <th width="120">Username</th>
    <td><input type="text" name="user" size="20"></td>
    </tr>
  <tr>
    <th width="120">Password</th>
    <td><input type="Password" name="pass" size="20"></td>
    </tr>
	  <tr>
    <td colspan="2" align="center"> 
    <input type="submit" name="submit" value="Login"></td>
    </tr>
    </table></center>
 
</form>
<?php include("footer.php"); ?>
